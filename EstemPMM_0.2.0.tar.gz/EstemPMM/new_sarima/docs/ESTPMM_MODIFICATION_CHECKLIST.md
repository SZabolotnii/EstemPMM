# Checklist для модифікації EstemPMM - Швидкий огляд

> **Мета**: Додати повну підтримку SARIMA з PMM2 для MA/SMA параметрів
> **Базується на**: Успішній реалізації в PMM2-SARIMA (R=500, 20.9-43.6% покращення)

---

## ✅ Checklist виконання

### Фаза 1: Підготовка (1-2 години)

- [ ] **1.1** Клонувати EstemPMM репозиторій
- [ ] **1.2** Створити нову гілку `feature/ma-pmm2-support`
- [ ] **1.3** Вивчити поточну структуру файлів:
  - [ ] `R/pmm2_ts_main.R` - головна функція
  - [ ] `R/pmm2_ar_estimator.R` - AR оцінка
  - [ ] `R/AllClasses.R` - S4 класи
- [ ] **1.4** Переглянути наші успішні реалізації:
  - [ ] `PMM2-SARIMA/R/experimental/06_estpmm_style_ma.R`
  - [ ] Результати Monte Carlo з `docs/ESTPMM_STYLE_PMM2_RESULTS.md`

---

### Фаза 2: Створення нових файлів (3-4 години)

#### 2.1 Основні функції MA/SMA

- [ ] **Створити** `R/pmm2_ma_estimator.R`:
  - [ ] `estpmm_ma()` - для MA(q)
  - [ ] `estpmm_sma()` - для SMA(Q)_s
  - [ ] `estpmm_mixed_ma()` - для MA(q) + SMA(Q)_s

**Копіювати з**: `PMM2-SARIMA/R/experimental/06_estpmm_style_ma.R`

#### 2.2 Допоміжні функції

- [ ] **Створити** `R/pmm2_ma_helpers.R`:
  - [ ] `ma_compute_innovations()`
  - [ ] `sma_compute_innovations()`
  - [ ] `ma_build_design()`
  - [ ] `sma_build_design()`
  - [ ] `ma_solve_pmm2()` - PMM2 solver з градієнтом

**Копіювати з**: Наших функцій в 06_estpmm_style_ma.R

---

### Фаза 3: Модифікація існуючих файлів (2-3 години)

#### 3.1 Головна функція

- [ ] **Модифікувати** `R/pmm2_ts_main.R`:
  - [ ] Додати параметр `ma_method = c("mle", "pmm2")`
  - [ ] Додати логіку вибору методу (3 випадки):
    - [ ] Тільки AR/SAR → поточна логіка
    - [ ] Тільки MA/SMA → MLE або PMM2 (новий)
    - [ ] AR+MA → Гібридний або повний PMM2 (новий)
  - [ ] Додати функцію `full_pmm2_sarima()` для повних моделей

**Див. детально**: `docs/ESTPMM_MODIFICATION_GUIDE.md` Крок 4

#### 3.2 S4 класи

- [ ] **Розширити** `R/AllClasses.R`:
  - [ ] Додати слоти: `vcov`, `loglik`, `aic`, `bic`

- [ ] **Розширити** `R/AllMethods.R`:
  - [ ] Методи `print()`, `summary()`
  - [ ] Методи `coef()`, `residuals()`, `fitted()`

---

### Фаза 4: Тестування (4-5 годин)

#### 4.1 Unit тести

- [ ] **Створити** `tests/testthat/test-estpmm-ma.R`:
  - [ ] Тест `estpmm_ma()` для MA(1)
  - [ ] Тест `estpmm_sma()` для SMA(1)_4
  - [ ] Тест `sarima_pmm()` з `ma_method="pmm2"`
  - [ ] Тест збіжності
  - [ ] Тест на помилки

**Запустити**: `devtools::test()`

#### 4.2 Monte Carlo валідація

- [ ] **Створити** `tests/monte-carlo/test-mc-estpmm-ma.R`:
  - [ ] R=500 симуляцій
  - [ ] MA(1), MA(2), SMA(1)_4, SMA(1)_12
  - [ ] Порівняння MLE vs PMM2
  - [ ] Перевірка покращення 20-44%

**Очікуваний результат**: MSE Ratio 0.56-0.79 (покращення 20-44%)

#### 4.3 Інтеграційні тести

- [ ] Тест повної SARIMA(1,0,1)(1,0,1)_12
- [ ] Тест зворотної сумісності (ma_method="mle")
- [ ] Тест різних розподілів інновацій

---

### Фаза 5: Документація (2-3 години)

#### 5.1 Roxygen документація

- [ ] **Оновити** документацію `sarima_pmm()`:
  - [ ] Додати опис параметра `ma_method`
  - [ ] Додати приклади використання
  - [ ] Додати розділ "When to use PMM2 for MA"
  - [ ] Додати посилання на результати

**Запустити**: `devtools::document()`

#### 5.2 Vignette

- [ ] **Створити** `vignettes/estpmm-ma-support.Rmd`:
  - [ ] Вступ та мотивація
  - [ ] Приклади MA(1), SMA(1)
  - [ ] Monte Carlo порівняння
  - [ ] Рекомендації використання

**Перевірити**: `devtools::build_vignettes()`

#### 5.3 Новини та changelog

- [ ] **Оновити** `NEWS.md`:
  ```md
  # EstemPMM 0.2.0

  ## New features

  * Added EstemPMM-style PMM2 for MA/SMA parameters
  * New parameter `ma_method` in `sarima_pmm()`: "mle" or "pmm2"
  * Support for mixed MA+SMA models via PMM2
  * Full SARIMA support with PMM2 for all components

  ## Improvements

  * 20-44% MSE improvement for asymmetric innovations
  * 100% convergence in Monte Carlo tests (R=500)
  * Fast convergence (3-5 iterations typically)
  * Extended S4 class with vcov, AIC, BIC

  ## Bug fixes

  * None
  ```

- [ ] **Оновити** `DESCRIPTION`:
  ```
  Version: 0.2.0
  Date: 2025-11-19
  ```

---

### Фаза 6: Перевірка та релиз (1-2 години)

#### 6.1 R CMD check

- [ ] **Запустити** `devtools::check()`:
  - [ ] 0 errors
  - [ ] 0 warnings
  - [ ] 0 notes (або пояснені)

#### 6.2 Code coverage

- [ ] **Перевірити** покриття тестами:
  ```r
  covr::package_coverage()
  ```
  - [ ] Цільове покриття: >80%

#### 6.3 Performance benchmarks

- [ ] Порівняти швидкість MLE vs PMM2
- [ ] Перевірити масштабованість (n = 100, 500, 1000, 5000)

#### 6.4 Зворотна сумісність

- [ ] Запустити всі існуючі тести
- [ ] Перевірити, що `ma_method="mle"` дає ті ж результати
- [ ] Перевірити старі приклади з документації

---

### Фаза 7: Git та релиз (30 хвилин)

#### 7.1 Git комміти

- [ ] Комміт 1: "Add EstemPMM-style PMM2 functions for MA/SMA"
- [ ] Комміт 2: "Modify sarima_pmm() to support ma_method parameter"
- [ ] Комміт 3: "Add tests and Monte Carlo validation"
- [ ] Комміт 4: "Add documentation and vignette"
- [ ] Комміт 5: "Update NEWS and version to 0.2.0"

#### 7.2 Pull request

- [ ] Створити PR з `feature/ma-pmm2-support` → `main`
- [ ] Додати опис з результатами Monte Carlo
- [ ] Додати checklist виконаних завдань
- [ ] Запросити review

#### 7.3 Release

- [ ] Після merge створити tag `v0.2.0`
- [ ] Створити GitHub release з changelog
- [ ] Опублікувати на CRAN (опціонально)

---

## 📋 Критичні файли для модифікації

### 🆕 Нові файли (створити):

```
EstemPMM/
├── R/
│   ├── pmm2_ma_estimator.R       ⭐ НОВИЙ - основні функції MA/SMA
│   └── pmm2_ma_helpers.R         ⭐ НОВИЙ - допоміжні функції
├── tests/
│   ├── testthat/
│   │   └── test-estpmm-ma.R      ⭐ НОВИЙ - unit тести
│   └── monte-carlo/
│       └── test-mc-estpmm-ma.R   ⭐ НОВИЙ - Monte Carlo
└── vignettes/
    └── estpmm-ma-support.Rmd     ⭐ НОВИЙ - документація
```

### 🔧 Існуючі файли (модифікувати):

```
EstemPMM/
├── R/
│   ├── pmm2_ts_main.R            ✏️ ЗМІНИТИ - додати ma_method
│   ├── AllClasses.R              ✏️ ЗМІНИТИ - розширити S4
│   └── AllMethods.R              ✏️ ЗМІНИТИ - додати методи
├── man/
│   └── sarima_pmm.Rd             ✏️ ЗМІНИТИ - оновити документацію
├── DESCRIPTION                   ✏️ ЗМІНИТИ - версія 0.2.0
└── NEWS.md                       ✏️ ЗМІНИТИ - додати changelog
```

---

## 🎯 Очікувані результати

### Monte Carlo валідація (R=500):

| Модель | MLE MSE | PMM2 MSE | Покращення |
|--------|---------|----------|------------|
| MA(1) | 0.003365 | 0.002663 | ✅ 20.9% |
| MA(2) θ₁ | 0.004634 | 0.002659 | ✅ 42.6% |
| MA(2) θ₂ | 0.004928 | 0.003308 | ✅ 32.9% |
| SMA(1)₄ | 0.003977 | 0.002491 | ✅ 37.4% |
| SMA(1)₁₂ | 0.004324 | 0.002437 | ✅ 43.6% |

**Середнє покращення**: 35.5%

### Продуктивність:

- ✅ 100% збіжність (500/500 симуляцій)
- ✅ Швидка збіжність (3-5 ітерацій)
- ✅ Стабільна робота для всіх моделей

---

## 🚨 Потенційні проблеми та рішення

### Проблема 1: Перший запуск дає помилку

**Рішення**:
- Перевірити, чи всі допоміжні функції імпортовані
- Запустити `devtools::load_all()` для перезавантаження
- Перевірити namespace конфлікти

### Проблема 2: Тести не проходять

**Рішення**:
- Почати з простих unit тестів
- Перевірити seed для відтворюваності
- Збільшити толеранс для числових порівнянь

### Проблема 3: R CMD check warnings

**Рішення**:
- Додати `@keywords internal` для допоміжних функцій
- Перевірити всі `@export` тільки для публічних функцій
- Додати приклади в документацію

### Проблема 4: Змішані моделі не збігаються

**Рішення**:
- Збільшити `max_outer_iter` до 20-30
- Покращити початкові значення через CSS
- Додати fallback до MLE якщо не збігається

---

## 📞 Підтримка

**Базові реалізації**:
- PMM2-SARIMA: `/Users/serhiizabolotnii/R/PMM2-SARIMA/R/experimental/`
- Документація: `/Users/serhiizabolotnii/R/PMM2-SARIMA/docs/`

**Детальний посібник**:
- `docs/ESTPMM_MODIFICATION_GUIDE.md` - повний посібник з кодом

**Результати**:
- `docs/ESTPMM_STYLE_PMM2_RESULTS.md` - результати R=500 Monte Carlo
- `results/extended_mc_estpmm_ma_r500.RData` - збережені дані

---

## ⏱️ Орієнтовний час виконання

| Фаза | Час | Складність |
|------|-----|------------|
| 1. Підготовка | 1-2 год | 🟢 Easy |
| 2. Нові файли | 3-4 год | 🟡 Medium |
| 3. Модифікація | 2-3 год | 🟡 Medium |
| 4. Тестування | 4-5 год | 🔴 Hard |
| 5. Документація | 2-3 год | 🟢 Easy |
| 6. Перевірка | 1-2 год | 🟡 Medium |
| 7. Релиз | 0.5 год | 🟢 Easy |
| **РАЗОМ** | **14-20 год** | |

**Рекомендація**: Розбити на 3-4 робочі дні по 4-6 годин

---

✅ **Готово до реалізації!**

**Версія checklist**: 1.0
**Дата**: 2025-11-19
**Базується на**: PMM2-SARIMA успішній реалізації (R=500, 20.9-43.6% покращення)
